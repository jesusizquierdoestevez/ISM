import java.io.Serializable;
public class Usuario implements Serializable{

    //atributos
    private int id;
    private String password;
    private String nombre;
    private String direccion;
    private String mail;
    private int telefono;

    //funciones
    //id
    public int getId() {
        return id;
    }
    public void setId(int newId) {
        id = newId;
    }

    //password
    public String getPassword() {
        return password;
    }
    public void setPassword(String newPassword) {
        password = newPassword;
    }

    //nombre
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String newNombre) {
        nombre = newNombre;
    }

    //direccion
    public String getDireccion() {
        return direccion;
    }
    public void setDireccion(String newDireccion) {
        direccion = newDireccion;
    }

    //mail
    public String getMail() {
        return mail;
    }
    public void setMail(String newMail) {
        mail = newMail;
    }

    //telefono
    public int getTelefono() {
        return telefono;
    }
    public void setTelefono(int newTelefono) {
        telefono = newTelefono;
    }

}
