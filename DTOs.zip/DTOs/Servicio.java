import java.io.Serializable;
public class Servicio implements Serializable{

    private int id;

	public int getId() {
		return id;
	}

	public void setId(int newId) {
		id = newId;
	}
    
}
